



//
//  Message.m
//  tonghua
//
//  Created by gjh on 15/12/20.
//  Copyright © 2015年 gjh. All rights reserved.
//

#import "Message.h"

@implementation Message

@end
