//
//  Message.h
//  tonghua
//
//  Created by gjh on 15/12/20.
//  Copyright © 2015年 gjh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Message : NSObject
@property (nonatomic,strong) NSString *content;
@property (nonatomic) BOOL fromMe;
@end
