//
//  ViewController.m
//  tonghua
//
//  Created by gjh on 15/12/19.
//  Copyright © 2015年 gjh. All rights reserved.
//
 /*
  MCNearbyServiceAssistant 可以接受数据，并处理用户请求链接的响应。会弹出默认的提示框，并处理链接
  MCNeerbyServiceAdvertiser 可以接受数据，并处理用户请求链接的响应，但是这个类有回调，告知有用户要与你的设备链接，可以自定义提示框，以及链接处理
  MCNearByServiceBrowser 用户搜索附近用户，并且可以对搜索到到用户发出邀请，加入某个会话中
  MCPeerID 这是用户信息
  MCSeesion启动和管理会话中的交流，发送数据。
  
  */
#import "ViewController.h"
#import "NSObject+HUD.h"
#import "Message.h"
#import <AVFoundation/AVFoundation.h>
#define kReceiveCell @"ReceiveCell"
#define kSendCell @"SenderCell"
#define kServiceType @"MyserviceType"
@import MultipeerConnectivity;

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,MCNearbyServiceAdvertiserDelegate,MCSessionDelegate,MCBrowserViewControllerDelegate,AVSpeechSynthesizerDelegate>
@property (weak, nonatomic) IBOutlet UIView *vview;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomC;
@property (weak, nonatomic) IBOutlet UITextField *textField;
// 用于广播自己，让别人可以发现你，并且链接
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) MCNearbyServiceAdvertiser *advertiser;
// 当前用户的信息，本机用户信息
@property (nonatomic,strong) MCPeerID *peerID;
//对方信息
@property (nonatomic,copy) MCPeerID *otherPeerID;
//会话：信息的传递
@property (nonatomic,strong) MCSession *session;
//搜索附近到蓝牙用户

@property (nonatomic,strong) MCNearbyServiceBrowser *browser;
//搜索附近蓝牙用户的界面，视图控制器
@property (nonatomic,strong) MCBrowserViewController *browserVC;

@property (nonatomic,strong) NSMutableArray *messageList;
@property (weak, nonatomic) IBOutlet UILabel *massage;
@property (nonatomic,assign) NSInteger mineNumber;
@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,strong) AVSpeechSynthesizer *synthesizer;
@property (nonatomic,assign) SystemSoundID systemID;
@property (nonatomic,strong) AVAudioPlayer *player;
@property (nonatomic,strong) NSString *strType;
@end

@implementation ViewController
BOOL it;

CGFloat buttonmargin = 5;
- (AVSpeechSynthesizer *)synthesizer{
    if (!_synthesizer) {
        _synthesizer = [AVSpeechSynthesizer new];
        _synthesizer.delegate = self;
    }
    return _synthesizer;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    it =NO;
    self.mineNumber = 15;
    self.array = [NSMutableArray array];
    CGFloat longth = [UIScreen mainScreen].bounds.size.width;
    for (int i = 0; i < self.mineNumber*self.mineNumber; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(30 + buttonmargin + i%self.mineNumber*((longth-self.mineNumber*buttonmargin-buttonmargin)/self.mineNumber+buttonmargin), buttonmargin + 40 + i/self.mineNumber*((longth-self.mineNumber*buttonmargin)/self.mineNumber+buttonmargin), (longth-self.mineNumber*buttonmargin - buttonmargin)/self.mineNumber, (longth-self.mineNumber*buttonmargin)/self.mineNumber)];
        UIButton *button = [UIButton new];
        [self.array addObject:button];
        button.tag = i;
        
        [button setTitle:@"0" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        
        label.backgroundColor = [UIColor lightGrayColor];
        if (i % 15 == 14 || i/15 ==14) {
            label.backgroundColor = [UIColor clearColor];
        }
        [button setBackgroundColor:[UIColor clearColor]];
        
        
        button.frame = CGRectMake(0, 0, 50, 50);
        button.center = label.frame.origin;
        [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:label];
        [self.view addSubview:button];
        
    }
    [self.view addSubview:self.vview];

}
#pragma  广播自己，让别人发现自己
- (MCNearbyServiceAdvertiser *) advertiser{
    if (!_advertiser) {
        _advertiser = [[MCNearbyServiceAdvertiser alloc]initWithPeer:self.peerID discoveryInfo:nil serviceType:kServiceType];
        _advertiser.delegate = self;
        
    }
    return _advertiser;
}
#pragma 创建自身的信息
- (MCPeerID *)peerID{
    if (!_peerID) {
        _peerID = [[MCPeerID alloc]initWithDisplayName:@"  嗨～～"];
    }
    return _peerID;
}
//当别人请求链接时，触发
- (void)advertiser:(MCNearbyServiceAdvertiser *)advertiser didReceiveInvitationFromPeer:(MCPeerID *)peerID withContext:(NSData *)context invitationHandler:(void (^)(BOOL, MCSession * _Nonnull))invitationHandler{
    NSLog(@"didRecieveInvitation");
    NSString *message = [NSString stringWithFormat:@"收到了来自 %@ 的邀请",peerID.displayName];
    
    [self showAlert:message];
    
    //传YES 代表同意邀请，使用session对象来保存这个邀请

    invitationHandler(YES,self.session);
    
    //
}
#pragma 会话
- (MCSession *)session{
    //参数2 加密
    if (!_session) {
        _session = [[MCSession alloc] initWithPeer:self.peerID securityIdentity:nil encryptionPreference:MCEncryptionNone];
        _session.delegate = self;
    }
    return _session;
}


#pragma 会话协议
//会话状态发生改变。正在链接
- (void)session:(MCSession *)session peer:(MCPeerID *)peerID didChangeState:(MCSessionState)state{
    NSLog(@"didchange");
    switch (state) {
        case MCSessionStateConnected:
            [self showAlert:@"已连接"];
            self.title = peerID.displayName;
            break;
        case MCSessionStateConnecting:
            [self showAlert:@"正在连接"];
            self.title = @"正在连接";
            break;
        case MCSessionStateNotConnected:
            [self showAlert:@"已断开"];
            self.title = @"已断开";
        default:
            break;
    }
}
//收到数据
- (void)session:(MCSession *)session didReceiveData:(NSData *)data fromPeer:(MCPeerID *)peerID{
    NSLog(@"didRecievedata");
    
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"didReceiveData%@%@",peerID.displayName,str);
    if ([str isEqualToString:@"聊天"]) {
        self.strType = @"聊天";
        return;
    }
    if ([str isEqualToString:@"下棋"]) {
        self.strType = @"下棋";
        return;
    }
    if ([str isEqualToString:@"重来"]) {
         [[NSOperationQueue mainQueue]addOperationWithBlock:^{
        for (int i = 0; i < self.array.count; i ++) {
            UIButton *button = self.array[i];
            [button setTitle:@"0" forState:UIControlStateNormal];
            [button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
            [button setBackgroundColor:[UIColor clearColor]];
            button.layer.borderColor = [UIColor clearColor].CGColor;
            button.enabled = YES;
            it = NO;
            self.massage.text = nil;
        }
         }];
        return;

    }
    if ([self.strType isEqualToString:@"聊天"]) {
        Message *message = [Message new];
        message.fromMe = NO;
        message.content = str;
        [self.messageList addObject:message];
        [[NSOperationQueue mainQueue]addOperationWithBlock:^{
            
            [_tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.messageList.count -1 inSection:0]] withRowAnimation:UITableViewRowAnimationBottom];
            [_tableView scrollToRowAtIndexPath:
             [NSIndexPath indexPathForRow:[self.messageList count]-1 inSection:0] atScrollPosition: UITableViewScrollPositionBottom
                                      animated:NO];
            

            
            
        }];

    }else{
        NSLog(@"%@",str);
        int click = [str intValue];
        UIButton *btn = self.array[click];
        btn.enabled = YES;
        if ([btn.currentTitle isEqualToString:@"0"]) {
            it = !it;
            NSString *AudioPath = [[NSBundle mainBundle]pathForResource:@"fish" ofType:@"wav"];
            NSURL *url = [NSURL fileURLWithPath:AudioPath];
            AudioServicesCreateSystemSoundID((__bridge CFURLRef  _Nonnull )(url), &_systemID);
            AudioServicesPlayAlertSound(_systemID);
         [[NSOperationQueue mainQueue]addOperationWithBlock:^{
            
            if (it) {
                [btn setBackgroundColor:[UIColor blackColor]];
                [btn setTitle:@"1" forState:UIControlStateNormal];
                [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            }else{
                [btn setBackgroundColor:[UIColor whiteColor]];
                [btn setTitle:@"-1" forState:UIControlStateNormal];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }
            
            btn.layer.masksToBounds = YES;
            btn.layer.cornerRadius = 25;
            
            btn.layer.borderWidth = 1;
            btn.layer.borderColor = [UIColor blackColor].CGColor;
            
         
          
            for (int i = 0; i < 5; i ++) {
                NSInteger sum = 0;
                int j = -4 + i;
                NSLog(@"j=%d",j);
                for (int k = 0; k < 5; k++) {
                    
                    
                    NSInteger inter;
                    if (btn.tag%15 < -j || btn.tag%15  >14 -j) {
                        inter = 0;
                        
                    }else {
                        UIButton *button = self.array[btn.tag+j];
                        inter = [button.currentTitle integerValue];
                    }
                    NSLog(@"inter=%ld",inter);
                    sum = sum + inter;
                    if (sum == 5||sum ==-5) {
                        if (it) {
                            self.massage.text = @"五连珠，黑方胜";
                            
                        }else{
                            self.massage.text = @"五连珠，白方胜";
                            
                        }
                        [self.view addSubview:self.massage];
                        AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                        utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                        utterance.pitchMultiplier = 1.0;
                        [self.synthesizer speakUtterance:utterance];
                        
                        
                        for (int y = 0; y <225; y++) {
                            UIButton *btt =  self.array[y];
                            btt.enabled = NO;
                        }
                        return;
                    }
                    j++;
                    
                }
                NSLog(@"sum=%ld",sum);
                
            }
            for (int i = 0; i < 5; i ++) {
                NSInteger sum = 0;
                int j = -60 + i*15;
                for (int k = 0; k < 5; k++) {
                    NSInteger inter;
                    int a = (int)btn.tag/15;
                    NSLog(@"a=%d,%d",a,-j/15);
                    if (a  > -1 - j/15 && a  <15 -j/15) {
                        NSLog(@"tag=%ld",btn.tag+j);
                        UIButton *button = self.array[btn.tag+j];
                        inter = [button.currentTitle integerValue];
                        NSLog(@"inter=%ld",inter);
                        
                    }else{
                        
                        inter = 0;
                    }
                    sum = sum + inter;
                    j = j + 15;
                }
                NSLog(@"sum=%ld",sum);
                if (sum == 5 || sum ==-5) {
                    if (it) {
                        self.massage.text = @"五连珠，黑方胜";
                        
                    }else{
                        self.massage.text = @"五连珠，白方胜";
                        
                        
                    }
                    [self.view addSubview:self.massage];
                    for (int y = 0; y <225; y++) {
                        UIButton *btt =  self.array[y];
                        btt.enabled = NO;
                    }
                    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                    utterance.pitchMultiplier = 1.0;
                    [self.synthesizer speakUtterance:utterance];
                    return;
                    
                }
            }
            
            for (int i = 0; i < 5; i ++) {
                NSInteger sum = 0;
                int j = -60 + i*15;
                int l =-4 + i;
                for (int k = 0; k < 5; k++) {
                    NSInteger inter;
                    if (btn.tag /15  < -j/15 || btn.tag /15 > 14 -j/15 || btn.tag%15 < -l || btn.tag%15 >14 - l) {
                        inter = 0;
                    }else{
                        NSLog(@"tag = %ld",btn.tag+j+l);
                        UIButton *button = self.array[btn.tag+j +l];
                        inter = [button.currentTitle integerValue];
                    }
                    NSLog(@"inter=%ld",inter);
                    sum = sum + inter;
                    j = j + 15;
                    l ++;
                }
                NSLog(@"sum=%ld",sum);
                if (sum == 5 || sum == -5) {
                    if (it) {
                        self.massage.text = @"五连珠，黑方胜";
                        //[self.player play];
                    }else{
                        self.massage.text = @"五连珠，白方胜";
                        //[self.player play];
                    }
                    [self.view addSubview:self.massage];
                    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                    utterance.pitchMultiplier = 1.0;
                    [self.synthesizer speakUtterance:utterance];
                    for (int y = 0; y <225; y++) {
                        UIButton *btt =  self.array[y];
                        btt.enabled = NO;
                        
                    }
                    return;
                    
                }
            }
            for (int i = 0; i < 5; i ++) {
                NSInteger sum = 0;
                int j = -60 + i*15;
                int l =4 - i;
                for (int k = 0; k < 5; k++) {
                    NSInteger inter;
                    if (btn.tag /15  < -j/15 || btn.tag /15 > 14 -j/15 || btn.tag%15 < -l || btn.tag%15 >14 - l) {
                        inter = 0;
                    }else{
                        NSLog(@"tag = %ld",btn.tag+j+l);
                        UIButton *button = self.array[btn.tag+j +l];
                        inter = [button.currentTitle integerValue];
                    }
                    NSLog(@"inter=%ld",inter);
                    sum = sum + inter;
                    j = j + 15;
                    l --;
                }
                NSLog(@"sum=%ld",sum);
                if (sum == 5 || sum == -5 ) {
                    if (it) {
                        self.massage.text = @"五连珠，黑方胜";
                        
                    }else{
                        self.massage.text = @"五连珠，白方胜";
                        
                    }
                    [self.view addSubview:self.massage];
                    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                    utterance.pitchMultiplier = 1.0;
                    [self.synthesizer speakUtterance:utterance];
                    for (int y = 0; y < 225; y++) {
                        UIButton *btt =  self.array[y];
                        btt.enabled = NO;
                    }
                    return;
                    
                }
            }
             }];
            for (int i = 0; i < self.array.count;  i++) {
                UIButton *but = self.array[i];
                if ([but.currentTitle isEqualToString:@"0"]) {
                    but.enabled = YES;
                }
                
            }

            
        }else
        {
            return;
        }

        
    }
}
//会话连接时
- (void)session:(MCSession *)session didReceiveCertificate:(NSArray *)certificate fromPeer:(MCPeerID *)peerID certificateHandler:(void (^)(BOOL))certificateHandler{
    NSLog(@"certificate");
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        
    
        [UIAlertView bk_showAlertViewWithTitle:peerID.displayName message:@"是否接受此人的邀请?" cancelButtonTitle:@"拒绝" otherButtonTitles:@[@"接受"] handler:^(UIAlertView *alertView, NSInteger buttonIndex) {
            if (buttonIndex == 1) {
                certificateHandler(YES);
                self.otherPeerID = peerID;
                [_browserVC dismissViewControllerAnimated:YES completion:nil];
            }else{
                certificateHandler(NO);
            }
        }];
    }];
    
}



#pragma 点击操作
- (IBAction)showSelf:(id)sender {
    [self.advertiser startAdvertisingPeer];
    
}
- (IBAction)searhDevice:(id)sender {
    
    _browserVC = [[MCBrowserViewController alloc]initWithServiceType:kServiceType session:self.session];
   
    _browserVC.delegate = self;
    [self presentViewController:_browserVC animated:YES completion:nil];
    
}
#pragma brower协议
- (void)browserViewControllerDidFinish:(MCBrowserViewController *)browserViewController{
    [browserViewController dismissViewControllerAnimated:YES completion:nil];
}
- (void)browserViewControllerWasCancelled:(MCBrowserViewController *)browserViewController{
   [browserViewController dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)sendText:(id)sender {
   
     [self.view endEditing:YES];
    self.strType = @"聊天";
    NSData *dataType = [self.strType dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    [self.session sendData:dataType toPeers:@[_otherPeerID] withMode:MCSessionSendDataReliable error:&error];
    
    if (_textField.text.length == 0) {
        [self showAlert:@"内容为空"];
        return;
    }
    NSData *data = [_textField.text dataUsingEncoding:NSUTF8StringEncoding];
    
    [self.session sendData:data toPeers:@[_otherPeerID] withMode:MCSessionSendDataReliable error:&error];
    if (error) {
        NSLog(@"error: %@",error);
    }else{
        NSLog(@"发送成功");
        Message *message = [Message new];
        message.fromMe = YES;
        message.content = _textField.text;
        [self.messageList addObject:message];
        _textField.text = @"";
        
        [_tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.messageList.count -1 inSection:0]] withRowAnimation:UITableViewRowAnimationBottom];
        [_tableView scrollToRowAtIndexPath:
         [NSIndexPath indexPathForRow:[self.messageList count]-1 inSection:0] atScrollPosition: UITableViewScrollPositionBottom
animated:NO];
        
        
    }
}
#pragma 键盘
- (void)keyboardWillShow:(NSNotification *)noti{
    CGFloat height = [noti.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    NSTimeInterval duration = [noti.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationOptions option = [noti.userInfo[UIKeyboardAnimationCurveUserInfoKey] intValue];
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        _bottomC.constant = height;
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
}
- (void)keyboardWillHide:(NSNotification *)noti{
    
    NSTimeInterval duration = [noti.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationOptions option = [noti.userInfo[UIKeyboardAnimationCurveUserInfoKey] intValue];
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        _bottomC.constant = 0;
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
}
#pragma 生命 周期
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    
}
#pragma tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.messageList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *indentify = kReceiveCell;
    Message *message = self.messageList[indexPath.row];
    if (message.fromMe) {
        indentify = kSendCell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indentify];
    UILabel *contentlb = (UILabel *)[cell.contentView viewWithTag:100];
    contentlb.text = message.content;
    contentlb.layer.cornerRadius = 6;
    contentlb.layer.masksToBounds = YES;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

- (NSMutableArray *)messageList {
	if(_messageList == nil) {
		_messageList = [[NSMutableArray alloc] init];
	}
	return _messageList;
}

- (void)clickButton:(UIButton *)btn{
    for (int i = 0; i < self.array.count;  i++) {
        UIButton *but = self.array[i];
        but.enabled = NO
        ;
    }
    self.strType = @"下棋";
    NSData *dataType = [self.strType dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    [self.session sendData:dataType toPeers:@[_otherPeerID] withMode:MCSessionSendDataReliable error:&error];
    NSString *str = [NSString stringWithFormat:@"%ld",btn.tag];
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    
    [self.session sendData:data toPeers:@[_otherPeerID] withMode:MCSessionSendDataReliable error:&error];
    btn.enabled = YES;
    if ([btn.currentTitle isEqualToString:@"0"]) {
        it = !it;
        NSString *AudioPath = [[NSBundle mainBundle]pathForResource:@"fish" ofType:@"wav"];
        NSURL *url = [NSURL fileURLWithPath:AudioPath];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef  _Nonnull )(url), &_systemID);
        AudioServicesPlayAlertSound(_systemID);
        
        
        if (it) {
            [btn setBackgroundColor:[UIColor blackColor]];
            [btn setTitle:@"1" forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }else{
            [btn setBackgroundColor:[UIColor whiteColor]];
            [btn setTitle:@"-1" forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
        
        btn.layer.masksToBounds = YES;
        btn.layer.cornerRadius = 25;
       
        btn.layer.borderWidth = 1;
        btn.layer.borderColor = [UIColor blackColor].CGColor;
        
        
        
        for (int i = 0; i < 5; i ++) {
            NSInteger sum = 0;
            int j = -4 + i;
            NSLog(@"j=%d",j);
            for (int k = 0; k < 5; k++) {
                
                
                NSInteger inter;
                if (btn.tag%15 < -j || btn.tag%15  >14 -j) {
                    inter = 0;
                    
                }else {
                    UIButton *button = self.array[btn.tag+j];
                    inter = [button.currentTitle integerValue];
                }
                NSLog(@"inter=%ld",inter);
                sum = sum + inter;
                if (sum == 5||sum ==-5) {
                    if (it) {
                        self.massage.text = @"五连珠，黑方胜";
                        
                    }else{
                        self.massage.text = @"五连珠，白方胜";
                      
                    }
                    [self.view addSubview:self.massage];
                    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                    utterance.pitchMultiplier = 1.0;
                    [self.synthesizer speakUtterance:utterance];
                    
                    
                    for (int y = 0; y <225; y++) {
                        UIButton *btt =  self.array[y];
                        btt.enabled = NO;
                    }
                    return;
                }
                j++;
                
            }
            NSLog(@"sum=%ld",sum);
            
        }
        for (int i = 0; i < 5; i ++) {
            NSInteger sum = 0;
            int j = -60 + i*15;
            for (int k = 0; k < 5; k++) {
                NSInteger inter;
                int a = (int)btn.tag/15;
                NSLog(@"a=%d,%d",a,-j/15);
                if (a  > -1 - j/15 && a  <15 -j/15) {
                    NSLog(@"tag=%ld",btn.tag+j);
                    UIButton *button = self.array[btn.tag+j];
                    inter = [button.currentTitle integerValue];
                    NSLog(@"inter=%ld",inter);
                    
                }else{
                    
                    inter = 0;
                }
                sum = sum + inter;
                j = j + 15;
            }
            NSLog(@"sum=%ld",sum);
            if (sum == 5 || sum ==-5) {
                if (it) {
                    self.massage.text = @"五连珠，黑方胜";
                  
                }else{
                    self.massage.text = @"五连珠，白方胜";
                   
                    
                }
                [self.view addSubview:self.massage];
                for (int y = 0; y <225; y++) {
                    UIButton *btt =  self.array[y];
                    btt.enabled = NO;
                }
                AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                utterance.pitchMultiplier = 1.0;
                [self.synthesizer speakUtterance:utterance];
                return;
                
            }
        }
        
        for (int i = 0; i < 5; i ++) {
            NSInteger sum = 0;
            int j = -60 + i*15;
            int l =-4 + i;
            for (int k = 0; k < 5; k++) {
                NSInteger inter;
                if (btn.tag /15  < -j/15 || btn.tag /15 > 14 -j/15 || btn.tag%15 < -l || btn.tag%15 >14 - l) {
                    inter = 0;
                }else{
                    NSLog(@"tag = %ld",btn.tag+j+l);
                    UIButton *button = self.array[btn.tag+j +l];
                    inter = [button.currentTitle integerValue];
                }
                NSLog(@"inter=%ld",inter);
                sum = sum + inter;
                j = j + 15;
                l ++;
            }
            NSLog(@"sum=%ld",sum);
            if (sum == 5 || sum == -5) {
                if (it) {
                    self.massage.text = @"五连珠，黑方胜";
                    //[self.player play];
                }else{
                    self.massage.text = @"五连珠，白方胜";
                    //[self.player play];
                }
                [self.view addSubview:self.massage];
                AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                utterance.pitchMultiplier = 1.0;
                [self.synthesizer speakUtterance:utterance];
                for (int y = 0; y <225; y++) {
                    UIButton *btt =  self.array[y];
                    btt.enabled = NO;
                    
                }
                return;
                
            }
        }
        for (int i = 0; i < 5; i ++) {
            NSInteger sum = 0;
            int j = -60 + i*15;
            int l =4 - i;
            for (int k = 0; k < 5; k++) {
                NSInteger inter;
                if (btn.tag /15  < -j/15 || btn.tag /15 > 14 -j/15 || btn.tag%15 < -l || btn.tag%15 >14 - l) {
                    inter = 0;
                }else{
                    NSLog(@"tag = %ld",btn.tag+j+l);
                    UIButton *button = self.array[btn.tag+j +l];
                    inter = [button.currentTitle integerValue];
                }
                NSLog(@"inter=%ld",inter);
                sum = sum + inter;
                j = j + 15;
                l --;
            }
            NSLog(@"sum=%ld",sum);
            if (sum == 5 || sum == -5 ) {
                if (it) {
                    self.massage.text = @"五连珠，黑方胜";
                    
                }else{
                    self.massage.text = @"五连珠，白方胜";
                   
                }
                [self.view addSubview:self.massage];
                AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.massage.text];
                utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh_CH"];
                utterance.pitchMultiplier = 1.0;
                [self.synthesizer speakUtterance:utterance];
                for (int y = 0; y < 225; y++) {
                    UIButton *btt =  self.array[y];
                    btt.enabled = NO;
                }
                return;
                
            }
        }
        
    }else
    {
        return;
    }
}
- (IBAction)restart:(id)sender {
    for (int i = 0; i < self.array.count; i ++) {
        UIButton *button = self.array[i];
        [button setTitle:@"0" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        [button setBackgroundColor:[UIColor clearColor]];
        button.layer.borderColor = [UIColor clearColor].CGColor;
        button.enabled = YES;
        it = NO;
        self.massage.text = nil;
    }
    NSString *strRestart = @"重来";
    NSData *dataRestart = [strRestart dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    [self.session sendData:dataRestart toPeers:@[_otherPeerID] withMode:MCSessionSendDataReliable error:&error];

}




@end
