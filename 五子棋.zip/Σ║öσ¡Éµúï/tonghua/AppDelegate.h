//
//  AppDelegate.h
//  tonghua
//
//  Created by gjh on 15/12/19.
//  Copyright © 2015年 gjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

