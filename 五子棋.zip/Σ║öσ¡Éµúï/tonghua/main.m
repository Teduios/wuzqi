//
//  main.m
//  tonghua
//
//  Created by gjh on 15/12/19.
//  Copyright © 2015年 gjh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
